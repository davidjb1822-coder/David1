# Level Up · Tienda de videojuegos

Página de ventas de videojuegos hecha con HTML, CSS y JavaScript puro (sin dependencias).

## Qué incluye

- Catálogo de juegos con descuentos calculados automáticamente
- Filtros por género
- Carrito lateral con cantidades y total
- Diseño adaptable a celular y modo oscuro automático

## Cómo usarla

1. Descarga o clona el repositorio.
2. Abre `index.html` en el navegador (o usa la extensión Live Server de VS Code).

## Cómo personalizarla

- **Juegos y precios:** edita el arreglo `JUEGOS` al inicio de `script.js`.
- **Moneda:** cambia `MONEDA` en `script.js`, por ejemplo `{ locale: "es-CO", code: "COP" }`.
- **Colores y tipografías:** edita las variables al inicio de `styles.css`.
- **Pagos:** el botón "Finalizar compra" es una demostración. Para cobrar de verdad, conecta una pasarela de pago (Stripe, MercadoPago, PayU, etc.).

## Publicarla gratis con GitHub Pages

En el repositorio: **Settings → Pages → Branch: main → Save**. En un par de minutos tendrás un enlace público.
