// ===== Datos: edita esta lista con tus juegos =====
const MONEDA = { locale: "es-US", code: "USD" };
const JUEGOS = [
  { id: 1, nombre: "Neon Drifter",     genero: "Carreras",   plataforma: "PC · PS5",      precio: 29.99, antes: 49.99, color: ["#FF4E8A","#7B2FF7"] },
  { id: 2, nombre: "Dungeon Hollow",   genero: "RPG",        plataforma: "PC · Switch",   precio: 24.99, antes: 39.99, color: ["#1FA2A6","#0B3D5C"] },
  { id: 3, nombre: "Pixel Farm Co.",   genero: "Simulación", plataforma: "PC · Switch",   precio: 14.99, antes: 19.99, color: ["#7BC950","#2F7D32"] },
  { id: 4, nombre: "Void Marines",     genero: "Acción",     plataforma: "PC · Xbox",     precio: 39.99, antes: 59.99, color: ["#FF8A3D","#8E1B1B"] },
  { id: 5, nombre: "Tiny Wizards",     genero: "RPG",        plataforma: "PC",            precio: 9.99,  antes: 17.99, color: ["#A78BFA","#312E81"] },
  { id: 6, nombre: "Goal Rush 26",     genero: "Deportes",   plataforma: "PS5 · Xbox",    precio: 44.99, antes: 69.99, color: ["#38BDF8","#1D4ED8"] },
  { id: 7, nombre: "Escape Room Zero", genero: "Puzles",     plataforma: "PC · Switch",   precio: 12.99, antes: 12.99, color: ["#FBBF24","#B45309"] },
  { id: 8, nombre: "Rift Arena",       genero: "Acción",     plataforma: "PC · PS5",      precio: 19.99, antes: 34.99, color: ["#F43F5E","#4C0519"] }
];

const $ = s => document.querySelector(s);
const fmt = n => new Intl.NumberFormat(MONEDA.locale, { style: "currency", currency: MONEDA.code }).format(n);
const carrito = new Map(); // id -> cantidad
let genero = "Todos";

// Filtros
const generos = ["Todos", ...new Set(JUEGOS.map(j => j.genero))];
function pintarFiltros(){
  $("#filtros").innerHTML = generos.map(g =>
    `<button class="chip" aria-pressed="${g === genero}" data-g="${g}">${g}</button>`).join("");
}
$("#filtros").addEventListener("click", e => {
  const b = e.target.closest("[data-g]"); if(!b) return;
  genero = b.dataset.g; pintarFiltros(); pintarJuegos();
});

// Catálogo
function pintarJuegos(){
  const lista = JUEGOS.filter(j => genero === "Todos" || j.genero === genero);
  $("#grid").innerHTML = lista.map(j => {
    const desc = Math.round((1 - j.precio / j.antes) * 100);
    return `<article class="game">
      <div class="cover" style="background:linear-gradient(135deg,${j.color[0]},${j.color[1]})">
        ${j.nombre.split(" ")[0]}
        ${desc > 0 ? `<span class="sticker">-${desc}%</span>` : ""}
      </div>
      <div class="info">
        <h3>${j.nombre}</h3>
        <small>${j.genero} · ${j.plataforma}</small>
        <div class="price"><strong>${fmt(j.precio)}</strong>${desc > 0 ? `<s>${fmt(j.antes)}</s>` : ""}</div>
        <button class="add" data-add="${j.id}">Añadir al carrito</button>
      </div>
    </article>`;
  }).join("");
}
$("#grid").addEventListener("click", e => {
  const b = e.target.closest("[data-add]"); if(!b) return;
  const id = +b.dataset.add;
  carrito.set(id, (carrito.get(id) || 0) + 1);
  pintarCarrito();
  b.textContent = "Añadido";
  setTimeout(() => b.textContent = "Añadir al carrito", 900);
});

// Carrito
function pintarCarrito(){
  let total = 0, cuenta = 0;
  const filas = [...carrito].map(([id, q]) => {
    const j = JUEGOS.find(x => x.id === id);
    total += j.precio * q; cuenta += q;
    return `<div class="item">
      <div><strong>${j.nombre}</strong><small>${fmt(j.precio)}</small></div>
      <div class="qty">
        <button data-menos="${id}" aria-label="Quitar uno">−</button>
        <span>${q}</span>
        <button data-mas="${id}" aria-label="Añadir uno">+</button>
      </div>
    </div>`;
  });
  $("#items").innerHTML = filas.join("") || `<p class="empty">Tu carrito está vacío. Añade un juego para empezar.</p>`;
  $("#total").textContent = fmt(total);
  $("#cuenta").textContent = cuenta;
  $("#pagar").disabled = cuenta === 0;
}
$("#items").addEventListener("click", e => {
  const mas = e.target.closest("[data-mas]"), menos = e.target.closest("[data-menos]");
  if(mas){ const id = +mas.dataset.mas; carrito.set(id, carrito.get(id) + 1); }
  if(menos){ const id = +menos.dataset.menos, q = carrito.get(id) - 1; q > 0 ? carrito.set(id, q) : carrito.delete(id); }
  pintarCarrito();
});

const panel = $("#panel"), veil = $("#veil");
function abrir(v){
  panel.classList.toggle("on", v); veil.classList.toggle("on", v);
  panel.setAttribute("aria-hidden", !v);
  if(v) $("#cerrar").focus(); else $("#abrir").focus();
}
$("#abrir").onclick = () => abrir(true);
$("#cerrar").onclick = veil.onclick = () => abrir(false);
document.addEventListener("keydown", e => { if(e.key === "Escape") abrir(false); });
$("#pagar").onclick = () => {
  // Aquí conectarías tu pasarela de pago (Stripe, MercadoPago, PayU, etc.)
  alert("¡Gracias por tu compra! Revisa tu correo para ver tus claves.");
  carrito.clear(); pintarCarrito(); abrir(false);
};

pintarFiltros(); pintarJuegos(); pintarCarrito();
